# #codevember 06-2016 <Download Button>

A Pen created on CodePen.io. Original URL: [https://codepen.io/fleeting/pen/qqEVzW](https://codepen.io/fleeting/pen/qqEVzW).

I really like playing with buttons. This time I went with a simple download button with a loading and success state. This would work well for downloads or submitting forms.

Icons from [FontAwesome](fontawesome.io).